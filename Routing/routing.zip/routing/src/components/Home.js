import React, { Component } from 'react';

class Home extends Component
{
    render()
    {
        return(
            <p> Hiiiiiiiiiiiiiiiiiiiiiiiiiiiii</p>
        )
    }
}
export default Home;