import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import './components/Counters.js';
import Counters from './components/Counters.js';
import Dishes from './components/Dishes.js';


class App extends Component {
  constructor(){
    super();
    this.state = {
      counter : 0,
      action : "",
      dishes:[{name:"dish1", price:20}, {name:"dish2", price:30}, {name:"dish3", price:40}]
    }
  }

increaseAll = () => {
  this.setState({
    // counter : this.state.counter + 1,
    action : "increase"
  })
}
decreaseAll = () => {
  this.setState({
    // counter : this.state.counter + 1,
    action : "decrease"
  })
}
add = () =>
{
  let abc = this.state.dishes;
  const c = abc.length;
  const newdish = {name : 'dish'+ (c+1), price : abc[c-1].price + 10};
  // console.log(newdish);
  abc.push(newdish);
    // console.log(abc);
    this.setState({
      dishes : abc
    })

    // console.log(this.state.dishes);
  

  
}
  render() {
    let {counter,action,dishes}=this.state;
   

    return (
      <div className="App">

        {/* {this.state.counter.map((key,value)=> <Counters key={key} value={value} increment={this.increment}  />)  } */}
        <Counters counter={counter} action={action} />
        <Counters counter={counter} action={action}/>
        <Counters counter={counter} action={action}/>
        
        <button type="button" className="counterButtons" onClick={this.increaseAll}>Increase all</button>
        <button type="button" className="counterButtons" onClick={this.decreaseAll}>decrease all</button>
        <hr/>
        <h1>MENU</h1>
        <p>please check console while clicking on dishes card to see their price</p>
        <div className="MenuContainer">
        {dishes.map((dish,i) => <Dishes dish={dish} key={i} /> )}
       
        </div>
        <button type="button" onClick={this.add}>Add Dishes</button>

      </div>
    );
  }
}

export default App;
