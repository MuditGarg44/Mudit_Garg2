import React, { Component } from 'react';
import './Countersss.css';

class Counters extends Component{
    constructor(props){
        super(props);
        this.state ={
            counter : this.props.counter ? this.props.counter : 0
        }
        
    }
    selfcall = () =>
    {
        this.state.counter = this.props.counter ? this.props.counter : 0;
    }
    increaseAll = () =>
    {
        this.props.increaseAll(this.state.counter);
    }


    counterMinus = () =>{
        if(this.state.counter != '0'){
            this.setState({
                counter : this.state.counter-1
            }
                )
        }
    }

    counterAdd = () => {
        this.setState({
            counter : this.state.counter+1
        }
            )
    }

    render() {
        const {counter} = this.state;
    return(
        <section> 
            {this.selfcall()}
            <button type="button" onClick={this.counterMinus}> - </button> 
            <input type="text" value={counter} readOnly /> 
            <button type="button" onClick={this.counterAdd}> + </button>
        
        
        </section>

    );
    }
}
export default Counters;