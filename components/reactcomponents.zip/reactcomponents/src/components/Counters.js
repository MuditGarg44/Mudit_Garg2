import React, { Component } from 'react';
import './Counters.css';

class Counters extends Component{
    constructor(props)
    {
        super(props);
        // console.log(this.props);
        this.state = {
            counter : this.props.counter
        }
    }

    componentWillReceiveProps(nextProps)
    {
        if(nextProps.action == "increase") {
        this.setState({
            counter : this.state.counter + 1
        }) }
        if(nextProps.action == "decrease") {
            if(this.state.counter != 0) 
            {
                this.setState({
                counter : this.state.counter - 1
                }) 
            }
        }    
    }
    

    plus = () =>
    {
        
        this.setState({
            counter : this.state.counter+1
        })
    }
    minus = () =>
    {
        if(this.state.counter != 0) 
        {
            this.setState({
            counter : this.state.counter-1
            });
        }   
    }
    render() {

    return(
        <section> 
            
            <button type="button" onClick={this.minus}> - </button> 
            <input type="text" readOnly value={this.state.counter}/> 
            <button type="button" onClick={this.plus}> + </button>
            
        
        </section>

    );
    }
}
export default Counters;