import React, { Component } from 'react';
import './Dishes.css';
// import { on } from 'cluster';

class Dishes extends Component {
    constructor(props)
    {
        super(props);
        console.log(props.dish);
        
    }
    
    show = () =>
    {
        
        console.log(` Price of ${this.props.dish.name} is Rs ${this.props.dish.price} only`);
    }
    render() {
        
        return (
            <section onClick={this.show}>
            <div className="card">{this.props.dish.name}</div>
            
            {/* <div> <button type="button">Add dish</button></div> */}
            </section>
        );
    }
}

export default Dishes;