import React, { Component } from 'react';
import './Aside.css';

class Aside extends Component{
    render() {
    return(
        <aside> Aside Tag </aside>

    );
    }
}
export default Aside;

