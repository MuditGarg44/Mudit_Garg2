import React, { Component } from 'react';
import './Footer.css';

class Footer extends Component{
    render() {
    return(
        <footer> Footer tag </footer>

    );
    }
}
export default Footer;