import React, { Component } from 'react';
import './Main.css';

class Main extends Component{
    hitcounter = () =>
    {
        console.log(this.props);
        this.props.getCounter(this.props.counter+1);
    }
    render() {
    return(
        <main> Main tag <button onClick={this.hitcounter}> Hit it </button> </main>

    );
    }
}
export default Main;