import React, { Component } from 'react';
import './Header.css';

class Header extends Component{
    

    render() {
    return(
        <header> Header tag Counter = <span>{this.props.counter} </span></header>

    );
    }
}
export default Header;