import React, { Component } from 'react';
// import './component/Header.js';
// import './component/Main.js';
// import './component/Footer.js';
import './component/Aside.js';
import logo from './logo.svg';
import './App.css';
import Header from './component/Header.js';
import Main from './component/Main.js';
import Footer from './component/Footer.js';
import Aside from './component/Aside';

class App extends Component {
  constructor(){
    super()
    this.state = {
      counter : 0
    }
  }
  getCounter = (counter) => {
    console.log(counter, " counter");
    this.setState({
      counter:counter
    });
  }
  render() {
    console.log(this.state);
    let {counter} = this.state;
    return (
      <div className="App">
        <Header counter={counter} />
          <div className="content">
            <Main counter={counter} getCounter={this.getCounter} />
            <Aside/>
          </div>
        <Footer/>
      </div>
    );
  }
}

export default App;
