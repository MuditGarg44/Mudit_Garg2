import React, { Component } from 'react';
import logo from './logo.svg';
import Items from './components/Items.js'
import './App.css';

class App extends Component {
  constructor()
  {
    super();
    this.state = {
      items:[{name: "mango", quantity: 1 , price: 20 },{name:"orange", quantity: 1, price:10}]
    }

  }
  componentWillMount()
  {
    alert("textbox has onBlur event, just press tab or click anywhere after input is complete to save data");
  }
  handleEvent = (e) => {
    console.log(this.state);
    if(e.target.value!==""){
    let itemList = this.state.items;
    let itemarr = e.target.value.split("-");
    itemarr[1] = parseInt(itemarr[1]);
    let newitem;
    let flag=0;
    
    
    this.state.items.map((item,i) => item.name == itemarr[0]?( newitem ={name:item.name, quantity:item.quantity + 1, price: (item.price + itemarr[1])}, itemList.splice(i,1,newitem),this.setState({ items : itemList }),flag=1,console.log(flag)) : 0);
    if(flag != 1)
    {
      newitem = {name:itemarr[0], quantity:1, price:itemarr[1]};
      itemList.push(newitem);
      this.setState({items : itemList});
    }

   
    
    console.log(this.state);
  }
    
  }

  deletecomponent = (nm) =>
  {
    let list = this.state.items;
    this.state.items.map((item,i) => item.name !== nm ? nm : list.splice(i, 1));
    this.setState({
      items : list
    })
  }
  add = (nm) =>
  {
    let list = this.state.items;
    let newitem;
    this.state.items.map((item,i) => item.name == nm?( newitem ={name:item.name, quantity:item.quantity + 1, price: (item.price + (item.price/item.quantity))}, list.splice(i,1,newitem),this.setState({ items : list })) : 0);
    
  }
  remove = (nm) =>
  {
    let list = this.state.items;
    let newitem;
    this.state.items.map((item,i) => item.name == nm?( newitem ={name:item.name, quantity:item.quantity - 1, price: (item.price - (item.price/item.quantity))},newitem.quantity==0?(list.splice(i,1),this.setState({items : list})):(list.splice(i,1,newitem),this.setState({ items : list }))  ) : 0);
    
  }
  
  render() {

    console.log(this.state);

    let r = 0;
    const addAll = () =>
    {
      for(let i = 0; i< this.state.items.length ; i++)
      {
        r = r + this.state.items[i].price;
      }
      return r ;
    };

    addAll()

    
    return (
      <div className="App">
        
       <h1>My cart</h1>
       <input type="text" className="txtbox" onBlur={this.handleEvent} placeholder="Enter ITEM and PRICE seperated by a hyphon (-)"/> 
       {this.state.items.map((item,i) => <Items item={item} key={i} deletefunc={this.deletecomponent} addfunc={this.add} removefunc={this.remove}/>)}
       <ul className="Total">
       <li>Total</li>
       <li>{r}</li>
       </ul>
      </div>
    );
  }
}

export default App;
