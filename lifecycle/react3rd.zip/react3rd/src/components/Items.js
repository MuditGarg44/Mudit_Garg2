import React, { Component } from 'react';
import './items.css';

export default class Items extends Component
{
    // constructor(props)
    // {
    //     super(props);
    //     // console.log(props);
    // }
    remove= () =>
        {
            this.props.deletefunc(this.props.item.name);
        }
    plus= () =>
    {
        this.props.addfunc(this.props.item.name);
    }
    minus= () =>
    {
        this.props.removefunc(this.props.item.name);
    }
    render() {
        
        return (
            //  <ul>
            //      <li className="name">{this.props.item.name}</li>
            //      <li>   <span className="quantity">{this.props.item.quantity}</span>
            //             <span className="price">{this.props.item.price}</span>
            //     </li>

                 
            //      <li className="minus" onClick={this.minus}>-</li>
            //      <li className="plus" onClick={this.plus}>+</li>
            //      <li className="cross" onClick={this.remove}>X</li>

            //  </ul>
             <table>
                 <tr> 
                    <td className="name">{this.props.item.name}</td>
                    <td className="quantity">{this.props.item.quantity}</td>
                    <td className="price">{this.props.item.price}</td>
                    <td className="minus" onClick={this.minus}>-</td>
                    <td className="plus" onClick={this.plus}>+</td>
                    <td className="cross" onClick={this.remove}>X</td>
                 
                 </tr>
             </table>
        );
    }
}
