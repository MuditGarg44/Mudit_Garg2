import React, { Component } from 'react';
import './Itemlist.css';

class Itemlist extends Component
{
    constructor()
    {
        super();
        
    }
    render() {

        return (
             <div className="itemstyle">
                <div>{this.props.item.desc}</div>
                <div className="Cross" onClick={()=>this.props.delete(this.props.index)}> X </div>
                 
             </div>
        )
    }
}
export default Itemlist;