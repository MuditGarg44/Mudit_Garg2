import React, { Component } from 'react';
import Itemlist from '../Itemlist/ItemList';
import list from '../List/List';
import './Todolist.css';
  
class Todolist extends Component
{
    constructor()
    {
        super()
        this.state = {
            items:list,
            newitem:""
        }
        console.log(this.state);
    }
    handleChange= (event) =>
    {
        this.setState({
            [event.target.name] : event.target.value
        });
  

    }
    handleClick= ()=>
    {
        const itemlist = this.state.items;
        const obj = {desc:""};
        obj.desc = this.state.newitem;
        itemlist.push(obj);
        this.setState({
            items : itemlist,   
            newitem:""
        });
    }

    delete = (index) =>
    {

        console.log(index);
        const itemlist = this.state.items;
        itemlist.splice(index,1);
        this.setState({
            items : itemlist
        });
    }

    

    render() {
        return (
             <section className="todobg">
                 <h1> Things to do : </h1>
                <input type="text" className="itemtxt" onChange={this.handleChange} value={this.state.newitem} name="newitem"/>
                <button type="button" onClick={this.handleClick} className="addbtn"> Add </button>
                <ul>
                {this.state.items.map((item,i)=> <li><Itemlist index={i} item={item} delete={this.delete}/> </li> )}
                </ul>   
                
             </section>
        );
    }
}
export default Todolist;