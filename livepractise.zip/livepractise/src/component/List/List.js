const list = [{desc:"Watch Shawshank Redemption on Monday"},{desc:"Watch Forrest Gump on Tuesday"},{desc:"organise pugs 6v6 in tf2 on wednesday"}];

export default list;